## yotta Target Description using GCC to compile for K64F Devkit

