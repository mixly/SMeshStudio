minar_platform
===============

Platform API for MINAR
