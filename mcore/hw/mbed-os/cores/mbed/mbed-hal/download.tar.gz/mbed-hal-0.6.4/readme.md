## mbed HAL

This module defines the API for the mbed low-level Hardware Abstraction Layer,
which is implemented by target-specific modules.

### Installation
```
yotta install --save ARMmbed/mbed-hal
```

### Usage
TBC


### API
TBC


