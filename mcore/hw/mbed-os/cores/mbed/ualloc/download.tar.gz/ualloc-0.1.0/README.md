# mbed-alloc
mbed allocator functions

Implements sbrk and a reverse sbrk for the never-free heap
