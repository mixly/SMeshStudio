# mbed utilities library

Implementation of various generic data structures and algorithms used in mbed.
