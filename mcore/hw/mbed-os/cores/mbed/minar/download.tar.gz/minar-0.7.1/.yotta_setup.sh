#! /bin/bash

wget https://github.com/ARMmbed/yotta/tarball/master
tar -xf master
pip install ./ARMmbed-yotta-*

