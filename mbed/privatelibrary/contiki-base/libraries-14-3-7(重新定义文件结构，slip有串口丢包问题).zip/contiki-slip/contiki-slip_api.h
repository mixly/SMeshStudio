/*
 * slip-conf.h
 *
 *  Created on: 2014-3-5
 *      Author: cheng
 */

#ifndef SLIP_CONF_H_
#define SLIP_CONF_H_

#ifdef __cplusplus
extern "C" {
#endif
#include "slip_uart.h"
#ifdef __cplusplus
}
#endif

#endif /* SLIP_CONF_H_ */
